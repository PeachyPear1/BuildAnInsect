﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuildAnInsect
{
    class Game
    { public int Lifespan { get; set; }
        public int Weight { get; set; }
        public string Species { get; set; }
        public string Name { get; set; }
    }
}
